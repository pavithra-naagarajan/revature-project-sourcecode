package demo;

public class W {
	public W() {
		System.out.println("W constructor");
	}

}
