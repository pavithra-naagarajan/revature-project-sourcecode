package demo;

public class DemoStatic {
	int num1=100;
	static int num2=200;
	
	public void display() {
		System.out.println("number1:"+num1);
		System.out.println("number2:"+num2);
	}
	public void changeNumber() {
		num2=--num1;
	}
	public DemoStatic() {
		num1=num2++;
	}
	public static void main(String[] args) {
		DemoStatic d1=new DemoStatic();
		DemoStatic d2=new DemoStatic();
		
		d1.changeNumber();
		d1.display();
		d2.display();
	}

}
