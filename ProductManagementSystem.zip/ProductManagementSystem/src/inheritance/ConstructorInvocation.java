package inheritance;

class Electronic {
	final int PRICE;
	public Electronic() {
		PRICE=100;
		System.out.println("electronic default cons-1");
		System.out.println(PRICE);
		
	}
	
	public Electronic(String name) {
		PRICE=200;
		System.out.println("electronic para cons-2");
		System.out.println(PRICE);
	}
	public void start() {
		System.out.println("start super");
	}

}


class Mobile extends Electronic{
	
	public Mobile() {
		super();
		System.out.println("mobile default cons-1");
	}
	public Mobile(String name) {
		super(name);
		System.out.println("mobile para cons-2");
	}
	public void start() {
		System.out.println("start statement");
		super.start();
	}
}
public class ConstructorInvocation {
	public static void main(String[] args) {
		Mobile m1=new Mobile("vivo");
		
		Mobile m2=new Mobile();
		m2.start();
		
		
	}
	

}
