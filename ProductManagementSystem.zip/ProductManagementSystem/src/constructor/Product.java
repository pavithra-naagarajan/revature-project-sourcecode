package constructor;

public class Product {
	int productId;
	String productName;
	int qualityOnHand;
	int price;
	
	public Product() {
		productId=10;
		productName="NA";
		qualityOnHand=100;
		price=0;
	}

	public Product(int productId, String productName, int qualityOnHand, int price) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.qualityOnHand = qualityOnHand;
		this.price = price;
	}

	public Product(int productId, String productName, int price) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.price = price;
	}
	
	

	public Product(String productName, int productId, int qualityOnHand) {
		super();
		this.productName = productName;
		this.productId = productId;
		this.qualityOnHand = qualityOnHand;
	}

	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + ", qualityOnHand=" + qualityOnHand
				+ ", price=" + price + "]";
	}
	public static void main(String[] args) {
		Product p1=new Product();
		System.out.println(p1);
		
		Product p2=new Product(123,"pavi",3,300);
		System.out.println(p2);
		
		Product p3=new Product(333,"logi",200);
		System.out.println(p3);
		
		Product p4=new Product("mathi",555,60);
		System.out.println(p4);
		
	}

}




