package constructor;

public class Patient {
	int patientId;
	public Patient() {
		patientId=999;
	}
	public Patient(int patientId) {
		this.patientId=patientId;
	}
	
	@Override
	public String toString() {
		return "Patient [patientId=" + patientId + "]";
	}
	public static void main(String[] args) {
		Patient p1 =new Patient();
		Patient p2 =new Patient(11);
		System.out.println(p1);
		System.out.println(p2);
	}

}
