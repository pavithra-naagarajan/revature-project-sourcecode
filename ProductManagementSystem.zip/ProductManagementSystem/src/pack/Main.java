package pack;
import pack1.*;
import pack2.*;
public class Main {
	public static void main(String[] args) {
		A obj =new A();
		obj.display();
		
		B obj1 =new B();
		obj1.display();
		
		C obj2 =new C();
		obj2.display();
		
		D obj3 =new D();
		obj3.display();
		
		E obj4 =new E();
		obj4.display();
		
		
	}

}
