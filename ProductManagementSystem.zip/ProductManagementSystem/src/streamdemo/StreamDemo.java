package streamdemo;

import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;

public class StreamDemo {

	public static void main(String[] args) {
		List<String> names=new LinkedList<String>();
		
		names.add("pavithra");
		names.add("haritha");
		names.add("ayisha");
		names.add("maala");
		names.add("pooja");
		names.add("pravithaa");
		
		List <String> newList=names.stream().filter(n->n.endsWith("a"))
				.filter(x->x.contains("i"))
				.filter(y->y.startsWith("p"))
				.map(String::toUpperCase)
				.sorted()
				.collect(Collectors.toList());
		
		//without newlist creation ...to print we can use .forEach(System.out::println); method
				
			System.out.println(newList);

	}

}
