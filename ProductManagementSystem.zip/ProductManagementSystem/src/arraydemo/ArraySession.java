package arraydemo;

public class ArraySession {
	
	public static void main(String[] args) {
		Employee[] employee=new Employee[5];
		
		for(int i=0;i<employee.length;i++) {
			employee[i]= new Employee();
		}
		employee[2].display();
		
		String namesOfEmp[]= {"pavi","logi","valar"};
		employee[1].display(namesOfEmp);
		
		employee[3].addNumbers();
		employee[3].addNumbers(1,3,5);
		
		System.out.println("result:"+employee[4].add(8, 7));
	}

}
