package arraydemo;

public class StringDemo {
	public static void main(String[] args) {
		String s1="Pavi";
		System.out.println(s1);
		
		System.out.println(s1.concat("thra"));
		String s2="Nagarajan";
		
		System.out.println(s1+s2);
		
		String s3="pavi";
		
		String s5=new String("Pavi");
		System.out.println(s1.equalsIgnoreCase(s3));
		
		System.out.println(s1.equals(s5));
		System.out.println(s1==s5);
		
		System.out.println("Substring: "+(s1+s2).substring(8,12));
		
		
	}

}
