package arraydemo;

public class Employee {
	public void display(String names[]) {
		for(String i:names) {
			System.out.println(i);
		}
	}
	public void display() {
		System.out.println("display non parameter method");
	}
	public int add(int num1,int num2) {
	
		return num1+num2;
		
	}
	
	public int addNumbers(int...numbers) {
		int ans=0;
		for(int t:numbers) {
			ans+=t;
		}
		System.out.println("Answer: "+ans);
		return ans;
	}

}
