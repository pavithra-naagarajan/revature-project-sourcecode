package jdk8features;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Patient {
private int patientId;
private String patientName;
 private int fee;

	
	

	public int getPatientId() {
		return patientId;
	}




	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}




	public String getPatientName() {
		return patientName;
	}




	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}




	public int getFee() {
		return fee;
	}




	public void setFee(int fee) {
		this.fee = fee;
	}




	@Override
	public String toString() {
		return "Patient [patientId=" + patientId + ", patientName=" + patientName + ", fee=" + fee + "]";
	}




	public Patient(int patientId, String patientName, int fee) {
		super();
		this.patientId = patientId;
		this.patientName = patientName;
		this.fee = fee;
	}




	public static void main(String[] args) {
		List<Patient> patients=new ArrayList<Patient>();
		patients.add(new Patient(4,"pavi",20000) );
		patients.add(new Patient(7,"anitha",7000) );
		patients.add(new Patient(1,"logi",100) );
		
		Comparator<Patient> comparator1=(o1,o2)->o1.getPatientName().compareTo(o2.getPatientName());
		Collections.sort(patients,comparator1);
		System.out.println("after sorting using lambda");
		System.out.println(patients);
		
		Comparator<Patient> comparator2=(o1,o2)->o1.getFee()>o2.getFee()?1:-1;
		Collections.sort(patients,comparator2);
		System.out.println("after sorting using lambda");
		System.out.println(patients);


	}

}
