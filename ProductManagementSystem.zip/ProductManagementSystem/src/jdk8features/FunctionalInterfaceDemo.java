package jdk8features;

public class FunctionalInterfaceDemo {
	public static void main(String[] args) {
	
		
		Calculation c=(a,b)->a+b;
		System.out.println(c.addNumbers(12, 3));
	}
}
