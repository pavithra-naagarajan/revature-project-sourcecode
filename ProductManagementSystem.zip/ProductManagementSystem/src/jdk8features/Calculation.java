package jdk8features;
public interface Calculation {
	int addNumbers(int num1,int num2);
}
