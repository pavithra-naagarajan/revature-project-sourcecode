package fileiodemos;

import java.io.File;
import java.io.FileWriter;   
import java.io.IOException;
import java.util.Scanner;

public class IODemo2 {
	public static void main(String[] args) {
		writeFile();
	}
	public static void writeFile() {
		Scanner s=new Scanner(System.in);
		File file=new File("E://about.txt");
		try {
			FileWriter writeobj=new FileWriter(file);
			writeobj.write(s.nextLine());
			writeobj.close();
			System.out.println("written successfully");
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		
		
	}

}