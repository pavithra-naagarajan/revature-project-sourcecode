package fileiodemos;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class ObjectFileDemo {
	
	public static void main(String[] args) {
		writeToFile();
	}

	private static void writeToFile() {
		
		System.out.println("*******object file***********");
		Patient patient=new Patient(1,"pavi",1000,"logi");
	
		try {
			ObjectOutputStream output = new ObjectOutputStream(new FileOutputStream(new File("E:\\patients.txt")));
			output.writeObject(patient);
			System.out.println("successfully written");
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	
		
		
	}
	

}
