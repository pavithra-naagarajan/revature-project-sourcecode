package fileiodemos;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class DemoIOFile {

	public static void main(String[] args) {
		readFromFile();

	}

	public static void readFromFile() {
		FileReader reader=null;
		File file=new File("E://fileiodemo.txt");
		try {
		if(file.exists()) {
			
				reader=new FileReader(file);
				int i=0;
				while((i=reader.read())!=-1) {
					System.out.print((char)i);
				}}
				else {file.createNewFile();
					System.out.println("file not exist and created");
					
				}
			} catch (FileNotFoundException e) {
				
				e.printStackTrace();
			} catch (IOException e) {
				
				e.printStackTrace();
			}
		
		}
	
		
	
		
}	
	
	

