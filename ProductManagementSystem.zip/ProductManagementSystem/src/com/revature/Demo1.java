package com.revature;

public class Demo1 {
	final int val1=0;
	public void display() {
		int val2;
		if(val1==0) 
			val2=10;
		System.out.println(val1+val2);
	}
	public static void main(String[] args) {
		Demo1 d=new Demo1();
		d.display();
		
	}

}
