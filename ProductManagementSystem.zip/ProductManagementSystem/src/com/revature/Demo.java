package com.revature;

public class Demo {
	
	
	
	public static void main(String[] args) {
		float var=(float)19.5;//explicit conversion
		
		byte x=10;//implicit conversion
		byte m=80;
		int res=x+m;//implicit conversion
		
		int y=100;
		float ans=y;
		
		long h=90;
		int i=(int)h;
		
		final long mn=12;
		int k=(int)mn;
		
		final char alpha='a';
		int c =alpha;
		
		final int b=124;
		byte z = b;
		
		int p=119;
		byte n=(byte)p;
		
		System.out.println(var);
		System.out.println(x);
		System.out.println(ans);
		System.out.println(ans+p);
		System.out.println(res);
		System.out.println(i);
		System.out.println(c);
		System.out.println(z);
		System.out.println(k);
		
		
		
		
	}

}
