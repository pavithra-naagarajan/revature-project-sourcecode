package com.revature.pms.exception;

public class ProductException {

}
