package com.revature.pms.model;

public class Product {

}
