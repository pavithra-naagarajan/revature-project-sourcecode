package singletondemo;

public class BankApplicationSingletonDemo {
	
	
	public static void main(String[] args) {
		Payment p1=Payment.getObjectPayment();
		p1.withdraw(1000);
		Payment p2=Payment.getObjectPayment();
		p1.withdraw(2000);
		Payment p3=Payment.getObjectPayment();
		p1.withdraw(3000);
	}

}
