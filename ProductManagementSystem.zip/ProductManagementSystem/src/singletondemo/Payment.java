package singletondemo;

public class Payment {
	
	private static Payment payment;
	
	private Payment() {
		System.out.println("object is created");
	}
	public static Payment getObjectPayment() {
		if(payment==null) {
			payment=new Payment();
		}
		
		return payment;
	}

	public void withdraw(int amount) {
		System.out.println("customer paid the payment "+ amount);
	}

}
