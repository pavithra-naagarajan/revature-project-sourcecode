package annotationsdemo;

import java.util.Date;

class Demo{
	public void display() {
		System.out.println("display the info-1");
	}
}

public class AnnotationDemo extends Demo {
	
	
	
	@Deprecated
	public void display() {
		System.out.println("display the info");
		
	}
	public static void main(String[] args) {
		AnnotationDemo obj=new AnnotationDemo();
		obj.display();
		
		Date d=new Date("12/09/2020");
		System.out.println(d);
	}

}
