package oops;

class Vehicle{
	int travelDistance=1000;
	int noOfBrakes=2;
	int tyres=4;
	
	public void displayDistance() {
		System.out.println("Distance to be Travelled: "+travelDistance);
	}
	public void details(int travelDistance,int tyres) {
		System.out.println("Traveldistance and tyres: "+travelDistance+" "+tyres);
	}
	
}

class Car extends Vehicle{
	
	int travelDistance=500;
	int time=3;
	
	public void displayDistance() {
		super.displayDistance();
		
		System.out.println("Distance to be Travelled within a child class: "+travelDistance);
	}
	
	
	
	public void calculateOfSpeed() {
		int travelDistance =750;
		int speed=travelDistance/time;
		
		int speedResult=this.travelDistance/time;
		
		int speedAnswer=super.travelDistance/time;
		
		System.out.println("calculated speed by local: "+speed);
		System.out.println("calculated speed by this class: "+speedResult);
		System.out.println("calculated speed by super class: "+speedAnswer);
	}
	
	
}


class Bike extends Vehicle{
	
	
	public void displayDistance() {
		System.out.println("Distance to be Travelled:"+travelDistance);
		
	}
	public void details(int travelDistance,int tyres) {
		super.details(super.travelDistance, super.tyres);
		System.out.println("Traveldistance and tyres: "+travelDistance+" "+tyres);
	}
	}
	

public class Demo {
	public static void main(String[] args) {
		Car c=new Car();
		c.displayDistance();
		
		c.calculateOfSpeed();
		
		Bike b=new Bike();
		b.displayDistance();
		b.details(100, 2);
	}

}
