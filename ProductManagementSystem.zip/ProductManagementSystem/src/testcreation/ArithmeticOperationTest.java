package testcreation;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class ArithmeticOperationTest {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.out.println("etUpBeforeClass");
		
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		System.out.println("tearDownAfterClass");
	}

	@Before
	public void setUp() throws Exception {
		System.out.println("setup");
	}

	@After
	public void tearDown() throws Exception {
		System.out.println("teardown");
	}

	@Test
	public void addtest1() {
		ArithmeticOperation arithmetic=new ArithmeticOperation();
		int actualResult=arithmetic.addNumbers(1, 2, 3);
		int expectedResult=6;
		assertequals(actualResult,expectedResult);
	}
	@Test
	public void addtest2() {
		ArithmeticOperation arithmetic=new ArithmeticOperation();
		int actualResult=arithmetic.addNumbers(1, 3, 3);
		int expectedResult=7;
		assertequals(actualResult,expectedResult);
	}


	private void assertequals(int actualResult, int expectedResult) {
		// TODO Auto-generated method stub
		
	}

}
