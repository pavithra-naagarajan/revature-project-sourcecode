package pack2;

import pack1.A;

public class E extends A {
	public void display() {
		A a =new A();
		System.out.println("In E"+a.num);
		
		System.out.println("In E"+num);
		
	}	

}
