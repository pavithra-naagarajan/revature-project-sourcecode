package pack1;

public class B extends A {
	public void display() {
		System.out.println("In B"+num);
		
		
		A a =new A();
		System.out.println("In B"+a.num);
	}

}
