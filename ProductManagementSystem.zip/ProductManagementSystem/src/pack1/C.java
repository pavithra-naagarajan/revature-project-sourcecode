package pack1;


public class C {
	public void display() {
		A a =new A();
		System.out.println("In C"+a.num);
		
		//System.out.println("In C"+ num);
		
	}		
}
