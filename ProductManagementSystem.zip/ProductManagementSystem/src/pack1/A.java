package pack1;

public class A {
	public int num=100;
	
	public void display() {
		
		System.out.println(num);
		
		
		A a=new A();
		System.out.println(a.num);
	}
}
