package interfaceproblem;

public interface AnimalCategory {
	public abstract void categoryOfAnimal();

}
