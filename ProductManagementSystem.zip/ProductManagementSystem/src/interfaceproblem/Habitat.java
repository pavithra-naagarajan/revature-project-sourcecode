package interfaceproblem;

public interface Habitat {
	public abstract void habitatType() ;
	public abstract void animalType();
}
