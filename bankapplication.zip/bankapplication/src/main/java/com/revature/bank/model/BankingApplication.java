package com.revature.bank.model;

import java.sql.Connection;



import java.util.List;

import java.util.Scanner;

import com.revature.bank.dao.BankDAO;
import com.revature.bank.dao.BankDAOImplementation;
import com.revature.bank.exception.InvalidAmountException;

public class BankingApplication {

	static Scanner s = new Scanner(System.in);
	BankDAO bankDAO = new BankDAOImplementation();

	Employee employee;
	Customer customer;

	public void startMenu()  {
		System.out.println("Home page:");
		System.out.println("\n1.Login\n2.Create Account\n0.Exit");
		System.out.println("Enter your choice:");
		int choice = s.nextInt();
		s.nextLine();
		while (true) {
			switch (choice) {
			case 1:
				login();
				break;
			case 2:
				createNewAccount();
				break;
			
			case 0:
				System.out.println("Thanks for using Banking Application!");
				System.exit(0);
				break;
			default:
				System.out.println("Incorrect input!........");
				break;
			}
		}

	}

	public void createNewAccount() {
		System.out.println("Welcome to Account Creation section:");
		System.out.println("Please Enter the details to open an account:");
		System.out.println("Enter your account type:\nE for Employee type account:\nC for customer type account: ");
		System.out.println("**********************************************************************");
		
		String accountType = s.nextLine();
		boolean v=true;
		while (true) {
			switch (accountType) {
			case "E":
				createAccountForEmployee();
				break;
			case "C":
				createAccountForCustomer();

				break;
			case "Z": 
				v=false;
				break;
			default:
				System.out.println("Incorrect type! Please enter the appropriate type........");
				break;
			}
		}
	}

	public void createAccountForCustomer() {

		System.out.println("Welcome to Customer Type account creation:");
		System.out.println("**********************************************************************");
		System.out.println("Enter customerId:");
		int customerId = s.nextInt();
		s.nextLine();
		System.out.println("Enter customerName:");
		String customerName = s.nextLine();
		System.out.println("Enter customerMobileNumber:");
		int customerMobileNumber = s.nextInt();
		s.nextLine();
		System.out.println("Enter customerMailId:");
		String customerMailId = s.nextLine();
		System.out.println("Enter customerPassword:");
		String customerPassword = s.nextLine();
		System.out.println("Enter customerPassword again to confirm:");
		String customerPasswordAgain = s.nextLine();
		System.out.println("Enter customerInitialBalance to start a new account:");
		int customerBalance = s.nextInt();
		s.nextLine();
		customer = new Customer(customerId, customerName, customerMobileNumber, customerMailId, customerPassword,
				customerBalance);
		bankDAO.employeeApproval(customer);
		
		System.out.println("**********************************************************************");
		login();

	}

	private void createAccountForEmployee()  {

		System.out.println("Welcome to Employee Type account creation:");
		System.out.println("**********************************************************************");
		System.out.println("Enter employeeId:");
		int employeeId = s.nextInt();
		s.nextLine();
		System.out.println("Enter employeeName:");
		String employeeName = s.nextLine();
		System.out.println("Enter employeeMobileNumber:");
		int employeeMobileNumber = s.nextInt();
		s.nextLine();
		System.out.println("Enter employeeMailId:");
		String employeeMailId = s.nextLine();
		System.out.println("Enter employeePassword:");
		String employeePassword = s.nextLine();
		System.out.println("Enter employeePassword again to confirm:");
		String employeePasswordAgain = s.nextLine();
		System.out.println("Enter employeeInitialBalance to start a new account:");
		int employeeBalance = s.nextInt();
		s.nextLine();
		employee = new Employee(employeeId, employeeName, employeeMobileNumber, employeeMailId, employeePassword,
				employeeBalance);
		System.out.println("Your account is created successfully!");
		System.out.println("**********************************************************************");
		bankDAO.addEmployee(employee);
		login();

	}

	private void login()  {
		System.out.println("Welcome to Login Section:");

		System.out.println("Please Enter the details to login:");
		System.out.println("Enter your account type:\nE for Employee type account:\nC for customer type account: ");
		System.out.println("**********************************************************************");
		boolean v=true;
		String accountType = s.nextLine();
		while (true) {
			switch (accountType) {
			case "E":
				loginForEmployee();
				break;
			case "C":
				loginForCustomer();
				break;
			case "Z":
				v=false;
				break;
			default:
				System.out.println("Incorrect type! Please enter the appropriate type........");
				break;

			}
		}
	}

	public void loginForCustomer(){
		System.out.println("Welcome to Customer Login Section:");
		System.out.println("Please Enter the details to login:");
		System.out.println("**********************************************************************");
		System.out.println("Enter customerId:");
		int customerId = s.nextInt();
		s.nextLine();
		System.out.println("Enter customerPassword:");
		String customerPassword = s.nextLine();
		int flag = 0;
		List<Customer> customers = bankDAO.getAllCustomers();
		for (Customer customer : customers) {
			if ((customer.getCustomerId() == customerId) && (customer.getCustomerPassword().equals(customerPassword))) {
				System.out.println("your Login is finished successfully");
				flag = 1;
			}
		}
		if (flag == 1) {
			System.out.println("Here your personal page! Welcome");
			BankApp bankApp = new BankApp();
			bankApp.personalPageForCustomer();
		}
		if (flag == 0) {
			System.out.println("you login details are not matched! try again");

		}
	}

	public void loginForEmployee()  {
		System.out.println("Welcome to Employee Login Section:");
		System.out.println("Please Enter the details to login:");
		System.out.println("**********************************************************************");
		System.out.println("Enter employeeId:");
		int employeeId = s.nextInt();
		s.nextLine();
		System.out.println("Enter employeePassword:");
		String employeePassword = s.nextLine();
		int flag = 0;

		List<Employee> employees = bankDAO.getAllEmployees();
		for (Employee employee : employees) {
			if ((employee.getEmployeeId() == employeeId) && (employee.getEmployeePassword().equals(employeePassword))) {
				System.out.println("your Login is finished successfully");
				flag = 1;
			}
		}
		if (flag == 1) {
			System.out.println("Here your personal page");
			BankApp bankApp = new BankApp();
			bankApp.personalPageForEmployee();
		}
		if (flag == 0) {
			System.out.println("you login details are not matched! try again");

		}
	}

	
}
