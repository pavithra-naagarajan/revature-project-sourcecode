package com.revature.pms.dao;




import org.hibernate.Transaction;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.revature.pms.model.Product;

public class ProductDAOImpl implements ProductDAO {

	private static Logger logger = Logger.getLogger("ProductDAOImpl");
	Configuration configuration = new Configuration().configure(); // hibernate.cfg.xml
	SessionFactory sessionFactory = configuration.buildSessionFactory();
	Session session = sessionFactory.openSession();

	public boolean addProduct(Product product) {
		Transaction transaction = session.beginTransaction();
		session.save(product);
		transaction.commit();
		return true;
	}

	public boolean deleteProduct(int productId) {

		return false;
	}

	public boolean updateProduct(Product product) {

		return true;
	}

	public Product getProductById(int productId) {

		return null;
	}

	public List<Product> getProductByName(String productName) {

		return null;
	}

	public List<Product> getAllProducts() {

		return null;
	}

	public boolean isProductExists(int productId) {

		return true;
	}

}
