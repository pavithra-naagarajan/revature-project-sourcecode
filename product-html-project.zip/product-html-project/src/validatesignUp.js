function validateSignUp() {
	
	
	var allFields = new Array();
	for (i = 0; i < 5; i++) {
		allFields[i] = document.forms[0].elements[i].value;
	}
	console.log(allFields)

	var username = document.getElementById("username").value;
	
	if (username.length == 0) {
		alert("please enter userName to proceed further!")
		return false
	}
	var password = document.getElementById("password").value;
	if (password.length == 0) {
		alert("please enter password")
		return false
	}
	
	else if (password.length < 6) {
			alert("please enter password atleast having 6 characters!")
			return false
		}
	else if (password.length > 10) {
			alert("please enter password atmost having 10 characters not more than that!")
			return false
		}
	var confirmPassword = document.getElementById("confirmPassword").value;
	if(confirmPassword.length==0){
		alert("enter password again to confirm")
		return false
	}
	else if (confirmPassword != password) {
		alert("confirm password is not matched")
		return false
	}
	
	
	//Mobile validation
	var mobileNumber = document.getElementById("mobileNumber").value;
	
	
	if (mobileNumber.length <10) {
		alert("Enter appropriate 10 digit mobileNumber")
		return false
	}
	
	
	//gender validation
	var group = document.forms[0].gender;
	for(var i=0;i<group.length;i++){
		if(group[i].checked)
		break;
	}
	if(i==group.length)
	{
		alert("select your gender please!")
		return false
	}
	
	//notification validation
	group= document.forms[0].notification;
	for(var i=0;i<group.length;i++){
		if(group[i].checked)
		break;
	}
	if(i==group.length)
	{
		alert("select your notification please!")
		return false
	}
	
	//payment validation
	group = document.forms[0].paymentOptions;
	for(var i=0;i<group.length;i++){
		if(group[i].checked)
		break;
	}
	if(i==group.length)
	{
		alert("select your paymentOptions please!")
		return false
	}
	return true
	
	
	
	


}





