function display1() {
		for (i = 1; i <= 5; i++) {
			document.write("<h1>Hello,Pavithra Welcome</h1>");
		}

	}