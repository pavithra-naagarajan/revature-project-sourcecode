
package com.revature.librarymanagement.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.revature.librarymanagement.controller.MailSend;
import com.revature.librarymanagement.dao.UserDAO;
import com.revature.librarymanagement.dto.UserDto;
import com.revature.librarymanagement.exception.DuplicateIdException;
import com.revature.librarymanagement.exception.IdNotFoundException;
import com.revature.librarymanagement.mapper.UserMapper;
import com.revature.librarymanagement.model.User;
import com.revature.librarymanagement.service.UserService;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserDAO userDAO;

	@Override
	public String addUser(UserDto userDto) {
		User user = UserMapper.dtoToEntity(userDto);
		Long userId = user.getUserId();
		String mailId = user.getMailId();
		String mobileNumber = user.getMobileNumber();
		if (userDAO.isUserExists(userId)) {
			throw new DuplicateIdException("User account with Id:"+userId+" already exists!");

		}

		if (userDAO.getUserByMailId(mailId) != null || userDAO.getUserByMobileNumber(mobileNumber) != null) {

			throw new DuplicateIdException("User account already exists with same details!");

		}

		MailSend.sendMail(user.getMailId(), "User Registration :",
				"Hii, " + user.getFirstName() + "\nYour account is created successfully!");

		return userDAO.addUser(user);

	}

	@Override
	public String updateUser(UserDto userDto) {
		User user = UserMapper.dtoToEntity(userDto);
		Long userId = user.getUserId();

		if (userDAO.isUserExists(userId))
			return userDAO.updateUser(user);

		else
			throw new IdNotFoundException("User with Id:" + userId + " Not Found to Update!");

	}

	@Override
	public String deleteUserById(Long userId) {
		if (userDAO.isUserExists(userId))

			return userDAO.deleteUserById(userId);
		else

			throw new IdNotFoundException("User Id:" + userId + " Not Found to delete!");

	}

	@Override
	public User getUserById(Long userId) {
		if (userDAO.isUserExists(userId))
			return userDAO.getUserById(userId);
		else

			throw new IdNotFoundException("User with Id:" + userId + " Not Found!");

	}

	@Override
	public List<User> getUserByFirstAndLastName(String name) {
		return userDAO.getUserByFirstAndLastName(name);

	}

	@Override
	public User getUserByMobileNumber(String mobileNumber) {
		return userDAO.getUserByMobileNumber(mobileNumber);
	}

	@Override
	public User getUserByMailId(String mailId) {
		return userDAO.getUserByMailId(mailId);
	}

	@Override
	public List<User> getUserByRole(String userRole) {
		return userDAO.getUserByRole(userRole);
	}

	@Override
	public boolean isUserExists(Long userId) {
		return userDAO.isUserExists(userId);
	}

	@Override
	public List<User> getAllUsers() {
		return userDAO.getAllUsers();

	}

	@Override
	public User userLogin(String mailId, String password) {
		return userDAO.userLogin(mailId, password);
	}

}
