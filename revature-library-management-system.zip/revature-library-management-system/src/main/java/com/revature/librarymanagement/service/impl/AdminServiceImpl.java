package com.revature.librarymanagement.service.impl;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.revature.librarymanagement.dao.AdminDAO;
import com.revature.librarymanagement.dto.AdminDto;
import com.revature.librarymanagement.exception.DuplicateIdException;
import com.revature.librarymanagement.exception.IdNotFoundException;
import com.revature.librarymanagement.mapper.AdminMapper;
import com.revature.librarymanagement.model.Admin;
import com.revature.librarymanagement.service.AdminService;

@Service
public class AdminServiceImpl implements AdminService  {

	
	
	@Autowired
	private AdminDAO adminDAO;
	
	@Override
	public Admin getAdminById(Long adminId) {
		if(adminDAO.isAdminExists(adminId)) {
			return  adminDAO.getAdminById(adminId);		}
		throw new IdNotFoundException("Admin Id:" + adminId + " Not Found!");
				
	}

	@Override
	public List<Admin> getAdminByName(String adminName) {
		return adminDAO.getAdminByName(adminName);
		
	}

	@Override
	public List<Admin> getAdminByRole(String adminRole) {
		return adminDAO.getAdminByRole(adminRole);
	}

	@Override
	public boolean isAdminExists(Long adminId) {
		return adminDAO.isAdminExists(adminId);
	}

	@Override
	public List<Admin> getAllAdmins() {
		return  adminDAO.getAllAdmins();
	}

	@Override
	public String deleteAdminById(Long adminId) {
		if(adminDAO.isAdminExists(adminId)) {
			return  adminDAO.deleteAdminById(adminId);		}
		throw new IdNotFoundException("Admin Id:" + adminId + " Not Found to delete!");
		
	}

	@Override
	public String addAdmin(AdminDto adminDto) {
		Admin admin=AdminMapper.dtoToEntity(adminDto);
		Long adminId=admin.getAdminId();

		if(adminDAO.isAdminExists(adminId)) {
			throw new DuplicateIdException("Admin account with Id:"+admin+" already exists!");

		}
		return adminDAO.addAdmin(admin);
	}

	@Override
	public String updateAdmin(AdminDto adminDto) {
		
		Admin admin=AdminMapper.dtoToEntity(adminDto);
		Long adminId=admin.getAdminId();
		if(adminDAO.isAdminExists(adminId)) {
			return adminDAO.updateAdmin(admin);
		}
		throw new IdNotFoundException("Admin Id:" + adminId + " Not Found to update!");

	}

	@Override
	public Admin adminLogin(Long adminId, String adminPassword) {
		return adminDAO.adminLogin(adminId,adminPassword);
	}

}
