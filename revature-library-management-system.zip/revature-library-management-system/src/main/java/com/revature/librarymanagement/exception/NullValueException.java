package com.revature.librarymanagement.exception;

public class NullValueException {

}
