package com.revature.librarymanagement.dao.impl;

import java.time.LocalDateTime;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.revature.librarymanagement.dao.AdminDAO;
import com.revature.librarymanagement.model.Admin;

@Repository
public class AdminDAOImpl implements AdminDAO {

	static final LocalDateTime localTime = LocalDateTime.now();

	@Autowired
	private SessionFactory sessionFactory;

	private static final String GET_ADMIN_BY_NAME = "select a from Admin a where a.adminName=?1";
	private static final String GET_ADMIN_BY_ROLE = "select a from Admin a where a.adminRole=?1";
	private static final String GET_ALL_ADMINS = "select a from Admin a";
	private static final String ADMIN_LOGIN = "select a from Admin a where a.adminId=?1 and a.adminPassword=?2";

	@Override
	public Admin getAdminById(Long adminId) {
		Session session = sessionFactory.getCurrentSession();

		return session.get(Admin.class, adminId);
	}

	@Override
	public List<Admin> getAdminByName(String adminName) {
		Session session = sessionFactory.getCurrentSession();

		List<Admin> resultList = session.createQuery(GET_ADMIN_BY_NAME, Admin.class).setParameter(1, adminName)
				.getResultList();
		return (resultList.isEmpty() ? null : resultList);
	}

	@Override
	public List<Admin> getAdminByRole(String adminRole) {
		Session session = sessionFactory.getCurrentSession();

		List<Admin> resultList = session.createQuery(GET_ADMIN_BY_ROLE, Admin.class).setParameter(1, adminRole)
				.getResultList();
		return (resultList.isEmpty() ? null : resultList);
	}

	@Override
	public boolean isAdminExists(Long adminId) {
		Session session = sessionFactory.getCurrentSession();
		Admin admin = session.get(Admin.class, adminId);
		return (admin != null);
	}

	@Override
	public List<Admin> getAllAdmins() {
		Session session = sessionFactory.getCurrentSession();

		Query<Admin> query = session.createQuery(GET_ALL_ADMINS, Admin.class);
		return (query.getResultList().isEmpty() ? null : query.getResultList());
	}

	@Transactional
	@Override
	public String deleteAdminById(Long adminId) {
		Admin admin = getAdminById(adminId);
		try(Session session = sessionFactory.getCurrentSession()) {

			session.delete(admin);
			return "Admin Account deleted with : " + adminId + " at " + localTime;

		}

	}

	@Transactional
	@Override
	public String addAdmin(Admin admin) {
		try(Session session = sessionFactory.getCurrentSession()) {

			session.save(admin);
			Long adminId = admin.getAdminId();
			return "Admin Account created with : " + adminId + " at " + localTime;

		} 

	}

	@Transactional
	@Override
	public String updateAdmin(Admin admin) {

		try (Session session = sessionFactory.getCurrentSession()){

			session.merge(admin);
			return "Admin details updated successfully!";

		}
		

	}

	@Override
	public Admin adminLogin(Long adminId, String adminPassword) {
		Session session = sessionFactory.getCurrentSession();

		List<Admin> resultList = session.createQuery(ADMIN_LOGIN, Admin.class).setParameter(1, adminId)
				.setParameter(2, adminPassword).getResultList();
		return (resultList.isEmpty() ? null : resultList.get(0));
	}

}
