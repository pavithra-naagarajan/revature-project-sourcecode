package com.revature.librarymanagement.service.impl;

import java.time.LocalDateTime;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.revature.librarymanagement.dao.IssueBookDAO;
import com.revature.librarymanagement.dto.IssueBookDto;
import com.revature.librarymanagement.exception.DuplicateIdException;
import com.revature.librarymanagement.exception.IdNotFoundException;
import com.revature.librarymanagement.mapper.IssueBookMapper;
import com.revature.librarymanagement.model.Book;
import com.revature.librarymanagement.model.IssueBook;
import com.revature.librarymanagement.model.User;
import com.revature.librarymanagement.service.IssueBookService;


@Service
public class IssueBookServiceImpl implements IssueBookService {
	@Autowired
	private IssueBookDAO issueBookDAO;

	@Override
	public String issueBook(IssueBookDto issueBookDto) {
		IssueBook issueBook=IssueBookMapper.dtoToEntity(issueBookDto);
		Long issueId=issueBook.getIssueId();
		if(issueBookDAO.isIssuedDetailsExists(issueId))
			throw new DuplicateIdException("Issued book already exists with same Id!");
		
		return issueBookDAO.issueBook(issueBook);
	}

	@Override
	public List<IssueBook> getAllIssuedBooks() {
		
		return issueBookDAO.getIssuedBooks();
	}

	
	

	@Override
	public IssueBook getDetailsByIssueId(Long issueId) {
		if(issueBookDAO.isIssuedDetailsExists(issueId))
			return issueBookDAO.getDetailsByIssueId(issueId);
		
		throw new IdNotFoundException("Issued Book details with:" + issueId + " Not Found!");
	}

	@Override
	public String updateIssuedBook(IssueBookDto issueBookDto) {
		IssueBook issueBook=IssueBookMapper.dtoToEntity(issueBookDto);
		Long issueId=issueBook.getIssueId();
		if(issueBookDAO.isIssuedDetailsExists(issueId))
			return issueBookDAO.updateIssuedBook(issueBook);
		
		throw new IdNotFoundException("Issued Book details with:" + issueId + " Not Found to update!");
	}

	@Override
	public String deleteIssuedBook(long issueId) {
		if(issueBookDAO.isIssuedDetailsExists(issueId))
			return issueBookDAO.deleteIssuedBook(issueId);
		
		throw new IdNotFoundException("Issued Book details with:" + issueId + " Not Found to delete!");
	}

	@Override
	public boolean isIssuedDetailsExists(Long issueId) {
		return issueBookDAO.isIssuedDetailsExists(issueId);
	}

	@Override
	public List<IssueBook>  getDetailsByUserId(User user) {
		return issueBookDAO.getDetailsByUserId(user);
	}

	@Override
	public IssueBook getDetailsByBookId(Book book) {
		return issueBookDAO.getDetailsByBookId(book);
	}

	@Override
	public List<IssueBook> getDetailsByIssueDate(LocalDateTime issueDate) {
		return issueBookDAO.getDetailsByIssueDate(issueDate);
	}

	@Override
	public List<IssueBook> getDetailsByDueDate(LocalDateTime dueDate) {
		return issueBookDAO.getDetailsByDueDate(dueDate);
	}

}
