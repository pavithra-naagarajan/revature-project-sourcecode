
package com.revature.librarymanagement.dao.impl;

import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.revature.librarymanagement.dao.UserDAO;
import com.revature.librarymanagement.model.User;

@Repository
public class UserDAOImpl implements UserDAO {

	static final LocalDateTime localTime = LocalDateTime.now();

	@Autowired
	private SessionFactory sessionFactory;

	private static final String GET_USER_BY_MOBILNUMBER = "select u from User u where u.mobileNumber=?1";
	private static final String GET_USER_BY_MAIL = "select u from User u where u.mailId=?1";
	private static final String GET_USER_BY_ROLE = "select u from User u where u.userRole LIKE?1";
	private static final String GET_ALL_USERS = "select u from User u";
	private static final String GET_USER_BY_NAME = "select u from User u where CONCAT(u.firstName,' ', u.lastName) LIKE ?1";
	private static final String USE_LOGIN = "select u from User u where u.mailId=?1 and u.password=?2";

	@Transactional
	@Override
	public String addUser(User user) {
		try (Session session = sessionFactory.getCurrentSession()) {
			user.setCreatedOn(new Date());

			session.save(user);

			return "User Account created with : " + user.getUserId() + " at " + localTime;
		}

	}

	@Transactional
	@Override
	public String updateUser(User user) {

		try(Session session = sessionFactory.getCurrentSession()) {
			user.setUpdatedOn(new Date());
			session.merge(user);
			return "User details updated successfully!";


		} 

	}

	@Transactional
	@Override
	public String deleteUserById(Long userId) {
		try(Session session = sessionFactory.getCurrentSession()) {
			User user = getUserById(userId);

			session.delete(user);
			return "User Account deleted with : " + userId + " at " + localTime;

		} 

	}

	@Override
	public User getUserById(Long userId) {
		Session session = sessionFactory.getCurrentSession();

		return session.get(User.class, userId);
	}

	@Override
	public User getUserByMobileNumber(String mobileNumber) {
		Session session = sessionFactory.getCurrentSession();

		List<User> resultList = session.createQuery(GET_USER_BY_MOBILNUMBER, User.class).setParameter(1, mobileNumber)
				.getResultList();
		return (resultList.isEmpty() ? null : resultList.get(0));
	}

	@Override
	public User getUserByMailId(String mailId) {
		Session session = sessionFactory.getCurrentSession();
		List<User> resultList = session.createQuery(GET_USER_BY_MAIL, User.class).setParameter(1, mailId)
				.getResultList();
		return (resultList.isEmpty() ? null : resultList.get(0));
	}

	@Override
	public List<User> getUserByRole(String userRole) {
		Session session = sessionFactory.getCurrentSession();
		List<User> resultList = session.createQuery(GET_USER_BY_ROLE, User.class).setParameter(1, "%" + userRole + "%")
				.getResultList();
		return (resultList.isEmpty() ? null : resultList);
	}

	@Override
	public boolean isUserExists(Long userId) {
		Session session = sessionFactory.getCurrentSession();
		User user = session.get(User.class, userId);
		return (user != null);
	}

	@Override
	public List<User> getAllUsers() {
		Session session = sessionFactory.getCurrentSession();
		Query<User> query = session.createQuery(GET_ALL_USERS, User.class);
		return (query.getResultList().isEmpty() ? null : query.getResultList());
	}

	@Override
	public List<User> getUserByFirstAndLastName(String name) {
		Session session = sessionFactory.getCurrentSession();

		List<User> resultList = session.createQuery(GET_USER_BY_NAME, User.class).setParameter(1, "%" + name + "%")
				.getResultList();

		return (resultList.isEmpty() ? null : resultList);
	}

	@Override
	public User userLogin(String mailId, String password) {
		Session session = sessionFactory.getCurrentSession();
		List<User> resultList = session.createQuery(USE_LOGIN, User.class).setParameter(1, mailId)
				.setParameter(2, password).getResultList();
		return (resultList.isEmpty() ? null : resultList.get(0));
	}

}
