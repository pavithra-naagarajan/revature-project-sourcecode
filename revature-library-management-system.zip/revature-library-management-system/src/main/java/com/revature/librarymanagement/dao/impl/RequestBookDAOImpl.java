package com.revature.librarymanagement.dao.impl;

import java.time.LocalDateTime;
import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.revature.librarymanagement.dao.RequestBookDAO;
import com.revature.librarymanagement.model.RequestBook;
import com.revature.librarymanagement.service.BookService;

@Repository
public class RequestBookDAOImpl implements RequestBookDAO {

	static final LocalDateTime localTime = LocalDateTime.now();

	@Autowired
	private SessionFactory sessionFactory;
	@Autowired
	BookService bookService;

	@Transactional
	@Override
	public String addRequestBook(RequestBook requestBook) {
		Session session = sessionFactory.getCurrentSession();
		try {

			Long bookId = requestBook.getBook().getBookId();
			bookService.updateBookStatus(bookId, "Requested");
			session.save(requestBook);

		} catch (HibernateException e1) {

			e1.printStackTrace();
		}

		return "Book request is added successfully at " + localTime;
	}

	@Override
	public List<RequestBook> getAllRequestedBooks() {
		Session session = sessionFactory.getCurrentSession();
		@SuppressWarnings("unchecked")
		Query<RequestBook> query = session.createQuery("select r from RequestBook r");
		return (query.getResultList().isEmpty() ? null : query.getResultList());
	}

	@Transactional
	@Override
	public String deleteRequestedBook(Long requestId) {
		Session session = sessionFactory.getCurrentSession();
		RequestBook requestedBook = getDetailsByRequestId(requestId);
		try {

			session.delete(requestedBook);
		} catch (HibernateException e1) {

			e1.printStackTrace();
		}

		return "Book requested details deleted at " + localTime;
	}

	@Override
	public RequestBook getDetailsByRequestId(Long requestId) {
		Session session = sessionFactory.getCurrentSession();

		return session.get(RequestBook.class, requestId);
	}

}
