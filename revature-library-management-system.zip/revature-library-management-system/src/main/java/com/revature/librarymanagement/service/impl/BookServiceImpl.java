package com.revature.librarymanagement.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.revature.librarymanagement.dao.BookDAO;
import com.revature.librarymanagement.dto.BookDto;
import com.revature.librarymanagement.exception.DuplicateIdException;
import com.revature.librarymanagement.exception.IdNotFoundException;
import com.revature.librarymanagement.mapper.BookMapper;
import com.revature.librarymanagement.model.Book;
import com.revature.librarymanagement.service.BookService;

@Service
public class BookServiceImpl implements BookService {

	@Autowired
	private BookDAO bookDAO;

	@Override
	public String addBook(BookDto bookDto) {
		Book book = BookMapper.dtoToEntity(bookDto);
		Long bookId = book.getBookId();
		Long isbn = book.getIsbn();
		if (bookDAO.isBookExists(bookId))
			throw new DuplicateIdException("Book with Id already exists!");

		if (bookDAO.getBookByISBN(isbn) != null)

			throw new DuplicateIdException("Book already exists with same ISBN details!");

		return bookDAO.addBook(book);
	}

	@Override
	public String updateBook(BookDto bookDto) {
		Book book = BookMapper.dtoToEntity(bookDto);
		Long bookId = book.getBookId();
		if (bookDAO.isBookExists(bookId))
			return bookDAO.updateBook(book);
		throw new IdNotFoundException("Book with Id:" + bookId + " Not Found to Update!");

	}

	@Override
	public String deleteBook(Long bookId) {
		
		if (bookDAO.isBookExists(bookId))
			return bookDAO.deleteBook(bookId);
		throw new IdNotFoundException("Book with Id:" + bookId + " Not Found to Delete!");

	}
	@Override
	public Book getBookById(Long bookId) {
		if (bookDAO.isBookExists(bookId))
			return bookDAO.getBookById(bookId);
		throw new IdNotFoundException("Book with Id:" + bookId + " Not Found!");

	}

	@Override
	public boolean isBookExists(Long bookId) {
		return bookDAO.isBookExists(bookId);
		

	}

	@Override
	public List<Book> getBookByName(String bookName) {
		return bookDAO.getBookByName(bookName);

	}

	@Override
	public List<Book> getBookByAuthor(String authorName) {
		return bookDAO.getBookByAuthor(authorName);
	}

	@Override
	public List<Book> getBookByGenre(String genre) {
		return bookDAO.getBookByGenre(genre);
	}

	@Override
	public List<Book> getAllBooks() {
		return bookDAO.getAllBooks();

	}

	@Override
	public Book getBookByISBN(Long isbn) {
		return bookDAO.getBookByISBN(isbn);
	}

	@Override
	public List<Book> getBookByPublisher(String publisher) {
		return bookDAO.getBookByPublisher(publisher);
	}

	@Override
	public String updateBookStatus(Long bookId, String status) {
		return bookDAO.updateBookStatus(bookId, status);
	}
}
