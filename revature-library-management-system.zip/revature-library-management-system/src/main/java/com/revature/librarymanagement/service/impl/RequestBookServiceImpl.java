package com.revature.librarymanagement.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.revature.librarymanagement.dao.RequestBookDAO;
import com.revature.librarymanagement.dto.RequestBookDto;
import com.revature.librarymanagement.mapper.RequestBookMapper;
import com.revature.librarymanagement.model.RequestBook;
import com.revature.librarymanagement.service.RequestBookService;


@Service
public class RequestBookServiceImpl implements RequestBookService{

	@Autowired
	private RequestBookDAO requestBookDAO;
	@Override
	public String addRequestBook(RequestBookDto requestBookDto) {
		RequestBook requestBook=RequestBookMapper.dtoToEntity(requestBookDto);
		
		return requestBookDAO.addRequestBook(requestBook);
	}
	@Override
	public List<RequestBook> getAllRequestedBooks() {
		return requestBookDAO.getAllRequestedBooks();
	}
	@Override
	public String deleteRequestedBook(Long requestId) {
		return requestBookDAO.deleteRequestedBook(requestId);
	}
	@Override
	public RequestBook getDetailsByRequestId(Long requestId) {
		return requestBookDAO.getDetailsByRequestId(requestId);
	}
	
	

	
	

}
