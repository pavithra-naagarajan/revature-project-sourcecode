package com.revature.librarymanagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.revature.librarymanagement.dto.AdminDto;

import com.revature.librarymanagement.exception.DuplicateIdException;
import com.revature.librarymanagement.exception.IdNotFoundException;
import com.revature.librarymanagement.model.Admin;
import com.revature.librarymanagement.service.AdminService;

@CrossOrigin(origins = "http://localhost:4200")

@RestController
@RequestMapping("admin")
public class AdminController {

	@Autowired
	AdminService adminService;

	// admin login
	@GetMapping("login/{adminId}/{adminPassword}")
	public ResponseEntity<Admin> adminLogin(@PathVariable("adminId") Long adminId,
			@PathVariable("adminPassword") String adminPassword) {

		return new ResponseEntity<>(adminService.adminLogin(adminId, adminPassword), HttpStatus.OK);

	}

	@PostMapping
	public ResponseEntity<String> addAdmin(@RequestBody AdminDto adminDto) {

		return new ResponseEntity<>(adminService.addAdmin(adminDto), HttpStatus.OK);

	}

	// update a admin

	@PutMapping
	public ResponseEntity<String> updateAdmin(@RequestBody AdminDto adminDto) {

		return new ResponseEntity<>(adminService.updateAdmin(adminDto), HttpStatus.OK);

	}
	// delete a admin

	@DeleteMapping("/{adminId}")
	public ResponseEntity<String> deleteAdmin(@PathVariable("adminId") Long adminId) {

		return new ResponseEntity<>(adminService.deleteAdminById(adminId), HttpStatus.OK);

	}
	// get admin by role

	@GetMapping("role/{adminRole}")
	public ResponseEntity<List<Admin>> getAdminByRole(@PathVariable String adminRole) {
		return new ResponseEntity<>(adminService.getAdminByRole(adminRole), HttpStatus.OK);

	}

	// get admin by name

	@GetMapping("name/{adminName}")
	public ResponseEntity<List<Admin>> getAdminByName(@PathVariable String adminName) {
		return new ResponseEntity<>(adminService.getAdminByName(adminName), HttpStatus.OK);
	}

	// get admin by adminId

	@GetMapping("/{adminId}")
	public ResponseEntity<Admin> getAdminById(@PathVariable Long adminId) {

		return new ResponseEntity<>(adminService.getAdminById(adminId), HttpStatus.OK);

	}

	// get all admins

	@GetMapping
	public ResponseEntity<List<Admin>> getAllAdmins() {

		return new ResponseEntity<>(adminService.getAllAdmins(), HttpStatus.OK);
	}

	// exception for Id not Found ..
	@ExceptionHandler(IdNotFoundException.class)

	public ResponseEntity<String> idNotFound(IdNotFoundException e) {

		return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
	}

	// exception for Duplicate Id insertion..
	@ExceptionHandler(DuplicateIdException.class)

	public ResponseEntity<String> duplicateIdFound(DuplicateIdException e) {
		return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
	}

}
