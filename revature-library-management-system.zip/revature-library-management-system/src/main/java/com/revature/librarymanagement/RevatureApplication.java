package com.revature.librarymanagement;

import org.springframework.boot.SpringApplication;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RevatureApplication {

	public static void main(String[] args) {
		SpringApplication.run(RevatureApplication.class, args);
	}

}
