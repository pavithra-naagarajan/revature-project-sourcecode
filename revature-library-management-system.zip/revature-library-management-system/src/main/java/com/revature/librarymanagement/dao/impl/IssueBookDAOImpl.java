package com.revature.librarymanagement.dao.impl;

import java.time.LocalDateTime;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.revature.librarymanagement.dao.IssueBookDAO;
import com.revature.librarymanagement.model.Book;
import com.revature.librarymanagement.model.IssueBook;
import com.revature.librarymanagement.model.User;
import com.revature.librarymanagement.service.BookService;

@Repository
public class IssueBookDAOImpl implements IssueBookDAO {

	static final LocalDateTime localTime = LocalDateTime.now();

	@Autowired
	private SessionFactory sessionFactory;

	@Autowired
	BookService bookService;

	private static final String GET_ALL_ISSUEDBOOKS = "select i from IssueBook i";
	private static final String GET_BY_USERID = "select i from IssueBook i where i.user=?1";
	private static final String GET_BY_BOOKID = "select i from IssueBook i where i.book=?1";
	private static final String GET_BY_ISSUEDATE = "select i from IssueBook i where i.issueDate=?1";
	private static final String GET_BY_DUEDATE = "select i from IssueBook i where i.dueDate=?1";

	@Transactional
	@Override
	public String issueBook(IssueBook issueBook) {

		Long issueId = null;
		try (Session session = sessionFactory.getCurrentSession()) {

			Long bookId = issueBook.getBook().getBookId();
			bookService.updateBookStatus(bookId, "Issued");
			session.save(issueBook);
			issueId = issueBook.getIssueId();
			return "Book is issued successfully with : " + issueId + " at " + localTime;

		}

	}

	@Override
	public List<IssueBook> getIssuedBooks() {
		Session session = sessionFactory.getCurrentSession();

		Query<IssueBook> query = session.createQuery(GET_ALL_ISSUEDBOOKS, IssueBook.class);
		return (query.getResultList().isEmpty() ? null : query.getResultList());
	}

	@Override
	public IssueBook getDetailsByIssueId(Long issueId) {
		Session session = sessionFactory.getCurrentSession();

		return session.get(IssueBook.class, issueId);
	}

	@Transactional
	@Override
	public String updateIssuedBook(IssueBook issueBook) {

		try (Session session = sessionFactory.getCurrentSession()) {

			session.merge(issueBook);
			return "Issued book details updated successfully!";

		}

	}

	@Transactional
	@Override
	public String deleteIssuedBook(long issueId) {

		IssueBook issuedDetails = getDetailsByIssueId(issueId);
		try (Session session = sessionFactory.getCurrentSession()) {

			session.delete(issuedDetails);
			return "Book issued details deleted with : " + issueId + " at " + localTime;

		}
	}

	@Override
	public boolean isIssuedDetailsExists(Long issueId) {
		Session session = sessionFactory.getCurrentSession();
		IssueBook issuedDetails = session.get(IssueBook.class, issueId);
		return (issuedDetails != null);
	}

	@Override
	public List<IssueBook> getDetailsByUserId(User user) {
		Session session = sessionFactory.getCurrentSession();

		List<IssueBook> resultList = session.createQuery(GET_BY_USERID, IssueBook.class).setParameter(1, user)
				.getResultList();
		return (resultList.isEmpty() ? null : resultList);
	}

	@Override
	public IssueBook getDetailsByBookId(Book book) {
		Session session = sessionFactory.getCurrentSession();

		List<IssueBook> resultList = session.createQuery(GET_BY_BOOKID, IssueBook.class).setParameter(1, book)
				.getResultList();
		return (resultList.isEmpty() ? null : resultList.get(0));
	}

	@Override
	public List<IssueBook> getDetailsByIssueDate(LocalDateTime issueDate) {
		Session session = sessionFactory.getCurrentSession();

		List<IssueBook> resultList = session.createQuery(GET_BY_ISSUEDATE, IssueBook.class).setParameter(1, issueDate)
				.getResultList();
		return (resultList.isEmpty() ? null : resultList);
	}

	@Override
	public List<IssueBook> getDetailsByDueDate(LocalDateTime dueDate) {
		Session session = sessionFactory.getCurrentSession();

		List<IssueBook> resultList = session.createQuery(GET_BY_DUEDATE, IssueBook.class).setParameter(1, dueDate)
				.getResultList();
		return (resultList.isEmpty() ? null : resultList);
	}
}
