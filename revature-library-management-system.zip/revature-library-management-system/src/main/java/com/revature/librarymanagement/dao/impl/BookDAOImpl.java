package com.revature.librarymanagement.dao.impl;

import java.time.LocalDateTime;

import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.revature.librarymanagement.dao.BookDAO;
import com.revature.librarymanagement.model.Book;

@Repository
public class BookDAOImpl implements BookDAO {

	static final LocalDateTime localTime = LocalDateTime.now();

	@Autowired
	private SessionFactory sessionFactory;
	
	private static final String GET_BOOK_BY_NAME = "select b from Book b where b.bookName LIKE ?1";
	private static final String GET_BOOK_BY_AUTHORNAME="select b from Book b where b.authorName LIKE?1";
	private static final String GET_BOOK_BY_GENRE="select b from Book b where b.genre=?1";
	private static final String GET_BOOK_BY_PUBLISHER="select b from Book b where b.publisher LIKE?1";
	private static final String GET_ALL_BOOKS ="select b from Book b";
	private static final String GET_BOOK_BY_ISBN="select b from Book b where b.isbn=?1";
	

	@Transactional
	@Override
	public String addBook(Book book) {

		
		try (Session session = sessionFactory.getCurrentSession()){
			book.setStatus("Available");
			book.setCreatedOn(new Date());
			session.save(book);

			Long bookId = book.getBookId();
			return "Book is added successfully : " + bookId + " at " + localTime;

		} 

	}

	@Transactional
	@Override
	public String updateBook(Book book) {
		try (Session session = sessionFactory.getCurrentSession()){
			book.setUpdatedOn(new Date());
			
			session.merge(book);
			return "Book updated successfully!";

		} 

	}

	@Transactional
	@Override
	public String deleteBook(Long bookId) {
		Book book = getBookById(bookId);
		try(Session session = sessionFactory.getCurrentSession()) {

			session.delete(book);
			return "Book deleted with : " + bookId + " at " + localTime;

		}


	}

	@Override
	public Book getBookById(Long bookId) {
		Session session = sessionFactory.getCurrentSession();

		return session.get(Book.class, bookId);

	}

	@Override
	public boolean isBookExists(Long bookId) {
		Session session = sessionFactory.getCurrentSession();
		Book book = session.get(Book.class, bookId);
		return (book != null);
	}

	@Override
	public List<Book> getBookByName(String bookName) {
		Session session = sessionFactory.getCurrentSession();
		List<Book> resultList = session.createQuery(GET_BOOK_BY_NAME,Book.class)
		  .setParameter(1, "%"+bookName+"%").getResultList(); 
		return ((resultList).isEmpty() ? null : resultList);
	}

	@Override
	public List<Book> getBookByAuthor(String authorName) {
		Session session = sessionFactory.getCurrentSession();

		List<Book> resultList = session.createQuery(GET_BOOK_BY_AUTHORNAME,Book.class)
				.setParameter(1,"%"+authorName+"%").getResultList();
		return (resultList.isEmpty() ? null : resultList);
	}

	@Override
	public List<Book> getBookByGenre(String genre) {
		Session session = sessionFactory.getCurrentSession();
		
		List<Book> resultList = session.createQuery(GET_BOOK_BY_GENRE,Book.class).setParameter(1, genre)
				.getResultList();
		return (resultList.isEmpty() ? null : resultList);
	}
	@Override
	public List<Book> getBookByPublisher(String publisher) {
		Session session = sessionFactory.getCurrentSession();
		
		List<Book> resultList = session.createQuery(GET_BOOK_BY_PUBLISHER,Book.class).setParameter(1, "%"+publisher+"%")
				.getResultList();
		return (resultList.isEmpty() ? null : resultList);
	}

	@Override
	public List<Book> getAllBooks() {
		Session session = sessionFactory.getCurrentSession();
		
		Query<Book> query = session.createQuery(GET_ALL_BOOKS,Book.class);
		return (query.getResultList().isEmpty() ? null : query.getResultList());
	}

	@Override
	public Book getBookByISBN(Long isbn) {
		Session session = sessionFactory.getCurrentSession();
		
		List<Book> resultList = session.createQuery(GET_BOOK_BY_ISBN,Book.class).setParameter(1, isbn)
				.getResultList();
		return (resultList.isEmpty() ? null : resultList.get(0));
	}

	@Transactional
	@Override
	public String updateBookStatus(Long bookId, String status) {

		try(Session session = sessionFactory.getCurrentSession()) {
			Book book=getBookById(bookId);
			book.setStatus(status);
			session.merge(book);
			return "Book Status updated successfully!";

		} 

	}

}
